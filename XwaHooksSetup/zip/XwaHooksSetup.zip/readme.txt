
XwaHooksSetup runs on Windows 32/64 bits with the .NET framework 4.8.
(Windows 7, Windows 8, Windows 10, Windows 11 or superior)

# Usage

1) Run XwaHooksSetup.exe.

2) It will create a directory named "Hooks" and download the hooks from GitHub into this directory. To redownload the hooks, delete the directory "Hooks".

3) It will create a directory named "Hooks_WIP" and download the WIP hooks from GitHub into this directory. To redownload the WIP hooks, delete the directory "Hooks_WIP".

4) It will extract the hooks into a directory named "Setup".

5) Copy the content of the "Setup" directory in your XWA install directory.
